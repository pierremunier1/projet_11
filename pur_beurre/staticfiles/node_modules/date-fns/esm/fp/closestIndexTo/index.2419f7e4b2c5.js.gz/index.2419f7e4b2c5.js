// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../closestIndexTo/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var closestIndexTo = convertToFP(fn, 2);
export default closestIndexTo;