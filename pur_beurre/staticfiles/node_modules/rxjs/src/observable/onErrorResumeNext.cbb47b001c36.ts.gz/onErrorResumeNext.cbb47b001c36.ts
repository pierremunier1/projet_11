import { onErrorResumeNextStatic } from '../operators/onErrorResumeNext';

export const onErrorResumeNext = onErrorResumeNextStatic;
