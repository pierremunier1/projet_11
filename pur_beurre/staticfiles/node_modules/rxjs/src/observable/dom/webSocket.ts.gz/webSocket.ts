import {  WebSocketSubject  } from './WebSocketSubject';

export const webSocket = WebSocketSubject.create;