// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../isSameYear/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var isSameYear = convertToFP(fn, 2);
export default isSameYear;