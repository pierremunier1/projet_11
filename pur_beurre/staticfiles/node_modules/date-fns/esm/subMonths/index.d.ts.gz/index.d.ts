// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { subMonths } from 'date-fns'
export default subMonths
