// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { getDaysInMonth } from 'date-fns/fp'
export default getDaysInMonth
