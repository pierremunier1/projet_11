# Change log

## 1.1.0 / 2016-08-10

- Bump minor (to fix a packaging error in 1.0.1)
- Update plist doctype

## 1.0.1 / 2016-08-09

- Add property list doctype

## 1.0.0 / 2015-01-22

- Initial release
