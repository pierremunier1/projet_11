import {  DeferObservable  } from './DeferObservable';

export const defer = DeferObservable.create;