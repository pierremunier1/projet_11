// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../startOfMonth/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var startOfMonth = convertToFP(fn, 1);
export default startOfMonth;