// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { setSeconds } from 'date-fns/fp'
export default setSeconds
