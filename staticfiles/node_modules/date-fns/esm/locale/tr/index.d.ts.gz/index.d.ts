// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { tr } from 'date-fns/locale'
export default tr
