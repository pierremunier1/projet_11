module.exports = {
  "dependencies": true,
  "internals": true,
  "has_own_property": true,
  "classes_array": true,
  "classes_object": true,
  "match_html": true
}
