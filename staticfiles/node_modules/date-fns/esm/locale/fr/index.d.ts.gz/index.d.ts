// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { fr } from 'date-fns/locale'
export default fr
