// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { ru } from 'date-fns/locale'
export default ru
