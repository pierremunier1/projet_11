// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { enGB } from 'date-fns/locale'
export default enGB
