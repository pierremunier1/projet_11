// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../endOfWeek/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var endOfWeek = convertToFP(fn, 1);
export default endOfWeek;