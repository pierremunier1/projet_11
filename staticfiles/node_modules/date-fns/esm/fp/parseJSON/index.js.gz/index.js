// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../parseJSON/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var parseJSON = convertToFP(fn, 1);
export default parseJSON;