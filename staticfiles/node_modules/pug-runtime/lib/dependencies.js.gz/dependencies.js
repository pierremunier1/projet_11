module.exports = {
  "has_own_property": [],
  "merge": [
    "style"
  ],
  "classes_array": [
    "classes",
    "escape"
  ],
  "classes_object": [
    "has_own_property"
  ],
  "classes": [
    "classes_array",
    "classes_object"
  ],
  "style": [
    "has_own_property"
  ],
  "attr": [
    "escape"
  ],
  "attrs": [
    "attr",
    "classes",
    "has_own_property",
    "style"
  ],
  "match_html": [],
  "escape": [
    "match_html"
  ],
  "rethrow": []
}
