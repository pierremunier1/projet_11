"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.minTime = exports.maxTime = void 0;

/**
 *  Maximum allowed time.
 *  @constant
 *  @type {number}
 *  @default
 */
var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1000;
/**
 *  Minimum allowed time.
 *  @constant
 *  @type {number}
 *  @default
 */

exports.maxTime = maxTime;
var minTime = -maxTime;
exports.minTime = minTime;