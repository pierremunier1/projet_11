// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../setISOWeek/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var setISOWeek = convertToFP(fn, 2);
export default setISOWeek;