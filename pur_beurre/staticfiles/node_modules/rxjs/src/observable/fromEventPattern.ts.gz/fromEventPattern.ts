import {  FromEventPatternObservable  } from './FromEventPatternObservable';

export const fromEventPattern = FromEventPatternObservable.create;