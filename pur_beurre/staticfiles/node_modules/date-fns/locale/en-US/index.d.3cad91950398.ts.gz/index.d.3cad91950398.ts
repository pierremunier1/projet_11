// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { enUS } from 'date-fns/locale'
export default enUS
