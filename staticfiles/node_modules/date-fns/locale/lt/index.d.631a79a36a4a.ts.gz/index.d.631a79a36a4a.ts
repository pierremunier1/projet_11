// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { lt } from 'date-fns/locale'
export default lt
