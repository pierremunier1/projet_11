// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { isPast } from 'date-fns'
export default isPast
