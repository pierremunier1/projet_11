// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { et } from 'date-fns/locale'
export default et
