// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../subMonths/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var subMonths = convertToFP(fn, 2);
export default subMonths;