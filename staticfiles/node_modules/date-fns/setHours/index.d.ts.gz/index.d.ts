// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { setHours } from 'date-fns'
export default setHours
