// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../getDate/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var getDate = convertToFP(fn, 1);
export default getDate;