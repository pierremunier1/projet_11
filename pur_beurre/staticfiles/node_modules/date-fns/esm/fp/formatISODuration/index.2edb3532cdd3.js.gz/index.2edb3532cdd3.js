// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../formatISODuration/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var formatISODuration = convertToFP(fn, 1);
export default formatISODuration;