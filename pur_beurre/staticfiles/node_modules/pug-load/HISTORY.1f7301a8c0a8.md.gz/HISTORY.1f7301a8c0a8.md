2.0.3 / 2016-08-24
==================

  * Do not pollute the user's `options` object

2.0.2 / 2016-08-23
==================

  * Only publish the module itself

2.0.1 / 2016-08-23
==================

  * Update to pug-walk@^1.0.0

2.0.0 / 2016-05-14
==================

  * Make filename part of the options - updates to the 2.x.y APIs for lexer and parser
