// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../differenceInCalendarISOWeeks/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var differenceInCalendarISOWeeks = convertToFP(fn, 2);
export default differenceInCalendarISOWeeks;