// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { endOfQuarter } from 'date-fns'
export default endOfQuarter
