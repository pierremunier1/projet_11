// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../formatDistanceStrict/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var formatDistanceStrict = convertToFP(fn, 2);
export default formatDistanceStrict;