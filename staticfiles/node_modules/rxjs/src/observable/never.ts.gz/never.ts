import {  NeverObservable  } from './NeverObservable';

export const never = NeverObservable.create;