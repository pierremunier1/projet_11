// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../isSameWeek/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var isSameWeekWithOptions = convertToFP(fn, 3);
export default isSameWeekWithOptions;