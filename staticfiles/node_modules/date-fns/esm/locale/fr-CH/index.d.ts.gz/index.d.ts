// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { frCH } from 'date-fns/locale'
export default frCH
