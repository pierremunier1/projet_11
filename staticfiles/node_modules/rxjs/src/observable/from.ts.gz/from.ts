import {  FromObservable  } from './FromObservable';

export const from = FromObservable.create;