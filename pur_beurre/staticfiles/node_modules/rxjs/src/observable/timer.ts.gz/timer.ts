import {  TimerObservable  } from './TimerObservable';

export const timer = TimerObservable.create;