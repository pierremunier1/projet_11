// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { gu } from 'date-fns/locale'
export default gu
