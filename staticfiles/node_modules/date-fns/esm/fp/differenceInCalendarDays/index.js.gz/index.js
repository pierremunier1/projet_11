// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../differenceInCalendarDays/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var differenceInCalendarDays = convertToFP(fn, 2);
export default differenceInCalendarDays;