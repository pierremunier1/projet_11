// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../addBusinessDays/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var addBusinessDays = convertToFP(fn, 2);
export default addBusinessDays;