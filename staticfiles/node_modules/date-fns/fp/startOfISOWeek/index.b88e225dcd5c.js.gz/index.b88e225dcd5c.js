"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _index = _interopRequireDefault(require("../../startOfISOWeek/index.js"));

var _index2 = _interopRequireDefault(require("../_lib/convertToFP/index.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
var startOfISOWeek = (0, _index2.default)(_index.default, 1);
var _default = startOfISOWeek;
exports.default = _default;
module.exports = exports.default;