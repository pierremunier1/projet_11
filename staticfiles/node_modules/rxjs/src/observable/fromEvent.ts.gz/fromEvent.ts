import {  FromEventObservable  } from './FromEventObservable';

export const fromEvent = FromEventObservable.create;