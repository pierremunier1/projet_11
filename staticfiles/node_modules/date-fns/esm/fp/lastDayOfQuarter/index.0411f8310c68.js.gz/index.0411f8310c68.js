// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from '../../lastDayOfQuarter/index.js';
import convertToFP from '../_lib/convertToFP/index.js';
var lastDayOfQuarter = convertToFP(fn, 1);
export default lastDayOfQuarter;